import json
import sqlite3
import csv
import os
import requests
import billboard
import matplotlib.pyplot as plt
import numpy as np
os.environ['SPOTIPY_CLIENT_ID']='ab463a3679544f58aa17e4f5bf167b94'
os.environ['SPOTIPY_CLIENT_SECRET']='e89458c8bda14001a50cfe0208d95852'
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials

path = os.path.dirname(os.path.abspath(__file__))
conn = sqlite3.connect(path+'/'+'MusicCharts.db')
cur = conn.cursor()

# country charts Spotify IDs
australia_top_25 = 'spotify:playlist:37i9dQZEVXbJPcfkRz0wJ0'
canada_top_25 = 'spotify:playlist:37i9dQZEVXbKj23U1GF4IR'
uk_top_25 = 'spotify:playlist:37i9dQZEVXbLnolsZ8PSNw'
ireland_top_25 = 'spotify:playlist:37i9dQZEVXbKM896FDX8L1'

# create lists of matching songs in each country's charts and the US chart
cur.execute('SELECT UStop100.title, Australiatop25.country_rank from UStop100 JOIN Australiatop25 ON UStop100.rank = Australiatop25.us_rank')
australia_song_matches = cur.fetchall()

cur.execute('SELECT UStop100.title, Canadatop25.country_rank from UStop100 JOIN Canadatop25 ON UStop100.rank = Canadatop25.us_rank')
canada_song_matches = cur.fetchall()

cur.execute('SELECT UStop100.title, UKtop25.country_rank from UStop100 JOIN UKtop25 ON UStop100.rank = UKtop25.us_rank')
uk_song_matches = cur.fetchall()

cur.execute('SELECT UStop100.title, Irelandtop25.country_rank from UStop100 JOIN Irelandtop25 ON UStop100.rank = Irelandtop25.us_rank')
ireland_song_matches = cur.fetchall()

# list of tuples with song match and country ranking for all of the countries
all_countries = australia_song_matches + canada_song_matches + uk_song_matches + ireland_song_matches

song_list = []
x_axis = []
us_list = []
australia = []
canada = []
ireland = []
uk = []

# create list of all matching song titles
for item in all_countries:
    title = item[0]
    song_list.append(title)
# go through list of song titles and find titles that appear 2 or more times
for song in song_list:
    if song_list.count(song) >= 2 and song not in x_axis:
        x_axis.append(song)

# go through popular song titles and create points for the song title's rank in each country
# rank = 0 if song not in country's chart
for song in x_axis:
    cur.execute('SELECT rank FROM UStop100 WHERE title = ?', (song, ))
    us_list.append(int(cur.fetchone()[0]))

    a_rank = 0
    for item in australia_song_matches:
        if item[0] == song:
            a_rank = item[1]
    australia.append(a_rank)

    c_rank = 0
    for item in canada_song_matches:
        if item[0] == song:
            c_rank = item[1]
    canada.append(c_rank)

    i_rank = 0
    for item in ireland_song_matches:
        if item[0] == song:
            i_rank = item[1]
    ireland.append(i_rank)

    u_rank = 0
    for item in uk_song_matches:
        if item[0] == song:
            u_rank = item[1]
    uk.append(u_rank)

print(us_list)
print(australia)
print(canada)
print(uk)
print(ireland)

print(x_axis)

fig, ax1 = plt.subplots()
n = len(x_axis)
width = 0.1
ind = np.arange(n)

# create bar for each country
p1 = ax1.bar(ind, us_list, width, color='blue')
p2 = ax1.bar(ind + width, australia, width, color='red')
p3 = ax1.bar(ind + 2*width, canada, width, color='green')
p4 = ax1.bar(ind + 3*width, ireland, width, color='yellow')
p5 = ax1.bar(ind + 4*width, uk, width, color='black')

ax1.set_xticks(ind + width / 5)
ax1.set_xticklabels(x_axis)
plt.xticks(rotation=90)
ax1.legend((p1[0],p2[0],p3[0],p4[0],p5[0]), ('US', 'Australia', 'Canada', 'Ireland', 'UK'))
ax1.set(xlabel='song title', ylabel='song rank',
       title='Popular Song Ranks in English Speaking Countries')
ax1.autoscale_view()

ax1.grid()

# pull whether each song on the matching songs for 2 more more countries is explicit or not from Spotify's API
auth_manager = SpotifyClientCredentials()
sp = spotipy.Spotify(auth_manager=auth_manager)
ex_count = 0

# pull remaining songs that aren't available on Australia's top 25 
for song in x_axis:
    response = sp.playlist_tracks(canada_top_25, fields=None, limit=25, offset = 1, market=None)
    for track in response['items']:
        title1 = track['track']['name'].split('(')[0].strip()
        title = title1.lower()
        if song == title:
            ex = track['track']['explicit']
            if ex == True:
                ex_count += 1

fig2 = plt.figure(2)
labels = 'Explicit', 'Clean'
ex_size = (ex_count/15)*100
clean_size = ((15-ex_count)/15)*100
sizes = [ex_size, clean_size]
explode = (0.1, 0)
colors = ['red', 'green']
plt.pie(sizes, explode=explode, labels=labels, colors=colors, autopct='%1.1f%%', shadow=True, startangle=90)
plt.axis('equal')

plt.show()